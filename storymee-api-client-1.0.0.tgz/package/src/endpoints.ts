export const API_ROUTES = {
    HR: {
        TEAM_MEMBERS: '/internal/v1/team/hr/team-members',
        ATTENDANCE: '/internal/v1/team/hr/attendance',
        ATTENDANCE_CHECKIN: '/internal/v1/team/hr/attendance/checkin',
        ATTENDANCE_CHECKOUT: '/internal/v1/team/hr/attendance/checkout',
        LEAVE_REQUESTS: '/internal/v1/team/hr/leave-requests',
        SUBTASKS: '/internal/v1/team/hr/subtasks',
        TASKS: '/internal/v1/team/hr/tasks'
    },
    PLANE: {
        ISSUES: '/internal/v1/team/plane/issues',
        PROJECTS: '/internal/v1/team/plane/projects',
        WORKSPACES: '/internal/v1/team/plane/workspaces'
    }
};
