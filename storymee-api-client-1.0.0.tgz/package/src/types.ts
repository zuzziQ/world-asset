export interface ITeamMember {
    id: string;
    fullName: string;
    email: string;
    role: string;
    skills?: string;
    telegramUsername?: string;
    telegramChatId?: string;
    planeMemberId?: string;
    bankName?: string;
    bankAccount?: string;
    phone?: string;
    lettaConversationId?: string;
    isRemote?: boolean;
    isActive?: boolean;
}

export interface ILeaveRequest {
    id: string;
    memberId: string;
    leaveType: 'remote' | 'leave';
    startDate: string | Date;
    endDate: string | Date;
    reason: string;
    status: 'pending' | 'approved' | 'rejected';
}

export interface IAttendance {
    id: string;
    memberId: string;
    checkInTime: string | Date;
    checkOutTime?: string | Date;
    notes?: string;
    workType?: 'office' | 'remote';
}

export interface ISubtask {
    id: string;
    title: string;
    status: 'backlog' | 'todo' | 'in_progress' | 'done' | 'archived' | 'In Review';
    estimatedHours?: number;
    priority?: string;
    assigneeId?: string;
    deadline?: string | Date;
}
