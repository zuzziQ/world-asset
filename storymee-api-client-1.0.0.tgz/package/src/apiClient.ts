import axios, { AxiosInstance, AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';

export interface ApiClientConfig extends AxiosRequestConfig {
    baseURL: string;
    timeout?: number;
    enforceApiPrefix?: boolean; // Legacy
    servicePrefix?: 'internal' | 'worker' | 'api' | string;
    apiVersion?: 'v1' | 'v2' | string;
}

export class CoreApiClient {
    private client: AxiosInstance;

    constructor(config: ApiClientConfig) {
        let baseURL = config.baseURL.replace(/\/+$/, '');
        
        // Use the new servicePrefix/apiVersion routing if provided
        if (config.servicePrefix || config.apiVersion) {
            const prefix = config.servicePrefix || 'internal';
            const version = config.apiVersion || 'v1';
            baseURL = `${baseURL}/${prefix}/${version}`;
        } 
        // Fallback to legacy /api prefix enforcement if explicitly needed
        else if (config.enforceApiPrefix !== false && !baseURL.endsWith('/api')) {
            baseURL = `${baseURL}/api`;
        }

        this.client = axios.create({
            baseURL,
            timeout: config.timeout || 15000, // Default 15s timeout
            headers: {
                'Content-Type': 'application/json',
                ...config.headers
            }
        });

        this.setupInterceptors();
    }

    private setupInterceptors() {
        this.client.interceptors.response.use(
            (response: AxiosResponse) => response,
            (error: AxiosError) => {
                // Return structured error instead of throwing a raw exception that might crash MCP
                const formattedError = {
                    message: error.message,
                    status: error.response?.status,
                    data: error.response?.data,
                    code: error.code
                };
                
                // Return a rejected promise with a standard error object
                return Promise.reject(formattedError);
            }
        );
    }

    private cleanUrl(url: string): string {
        if (url.startsWith('http://') || url.startsWith('https://')) return url;
        
        let basePath = '';
        try {
            if (this.client.defaults.baseURL) {
                const urlObj = new URL(this.client.defaults.baseURL);
                basePath = urlObj.pathname.replace(/\/+$/, '');
            }
        } catch (e) {}

        let clean = url;
        if (basePath && basePath.length > 0 && clean.startsWith(basePath)) {
            clean = clean.substring(basePath.length);
        }
        
        return clean.startsWith('/') ? clean.substring(1) : clean;
    }

    public async get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
        const response = await this.client.get<T>(this.cleanUrl(url), config);
        return response.data;
    }

    public async post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
        const response = await this.client.post<T>(this.cleanUrl(url), data, config);
        return response.data;
    }

    public async put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
        const response = await this.client.put<T>(this.cleanUrl(url), data, config);
        return response.data;
    }

    public async patch<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<T> {
        const response = await this.client.patch<T>(this.cleanUrl(url), data, config);
        return response.data;
    }

    public async delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
        const response = await this.client.delete<T>(this.cleanUrl(url), config);
        return response.data;
    }
}
