const axios = require('axios');
const client = axios.create({ baseURL: 'http://localhost:5100/internal/v1/team' });
console.log(client.getUri({ url: 'hr/team-members' }));
